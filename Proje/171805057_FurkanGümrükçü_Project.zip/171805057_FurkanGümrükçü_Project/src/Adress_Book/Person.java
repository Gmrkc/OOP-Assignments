package Adress_Book;

public class Person {
	private String ID;
	private String name;
	private String gender;
	private String street;
	private String city;
	private String zip;
	
	public Person(int ID,String name, String gender, String street, String city,String zip) {
		super();
		this.ID=String.valueOf(ID);
		this.name = name;
		this.gender = gender;
		this.street = street;
		this.city = city;
		this.zip = zip;
	}

	public String getID() {
		return ID;
	}



	public void setID(String iD) {
		ID = iD;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}
	
	@Override
	public String toString()
	{
		return  getID()+" "+getName()+ " "+ getStreet()+ " "+ getCity()+" "+ getGender()+ " "+ getZip();
		
	}

}
