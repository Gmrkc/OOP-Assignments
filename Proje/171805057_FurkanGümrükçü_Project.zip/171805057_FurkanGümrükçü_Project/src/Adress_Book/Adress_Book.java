/* Fatih SA�LAM 171805072
 * Fatih BI�KI 181805030
 * Furkan G�MR�K�� 171805057
 */



package Adress_Book;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.RandomAccessFile;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Color;

public class Adress_Book {

	private JFrame frame;
	private static JTextField txtID;
	private JTextField txtSearchID;
	private static JTextField txtName;
	private static JTextField txtStreet;
	private static JTextField txtCity;
	private static JTextField txtGender;
	private static JTextField txtZip;
	static int i=0;
	static int ID=1;
	static Person[] pArray;
	final static int ID_SIZE=4;
	final static int NAME_SIZE = 32;
	final static int STREET_SIZE = 32;
	final static int CITY_SIZE = 20;
	final static int GENDER_SIZE = 1;
	final static int ZIP_SIZE = 5;
	final static int RECORD_SIZE =(NAME_SIZE + STREET_SIZE + CITY_SIZE + GENDER_SIZE + ZIP_SIZE);
	public static RandomAccessFile raf;
	public void Uptade_Person(int id,String name,String street, String city,String gender,String zip) throws IOException {
		pArray[id].setName(name);
		pArray[id].setStreet(street);
		pArray[id].setCity(city);
		pArray[id].setGender(gender);
		pArray[id].setZip(zip);
		long position= RECORD_SIZE*2*(id);
		SaveFile(position);
	}
	public void SaveFile(long position) {
		try {
			raf.seek(position);
			File_Operations.writeFixedLengthString(txtName.getText(), NAME_SIZE, raf);
			File_Operations.writeFixedLengthString(txtStreet.getText(), STREET_SIZE, raf);
			File_Operations.writeFixedLengthString(txtCity.getText(), CITY_SIZE, raf);
			File_Operations.writeFixedLengthString(txtGender.getText(), GENDER_SIZE, raf);
			File_Operations.writeFixedLengthString(txtZip.getText(), ZIP_SIZE, raf);
		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	public static void ReadFile(Person[]people,long position) throws IOException {
		raf.seek(position);
		int ID=i+1;
		String name = File_Operations.readFixedLengthString(NAME_SIZE, raf).trim();
		String street = File_Operations.readFixedLengthString(STREET_SIZE, raf).trim();
		String city = File_Operations.readFixedLengthString(CITY_SIZE, raf).trim();
		String gender= File_Operations.readFixedLengthString(GENDER_SIZE, raf).trim();
		String zip = File_Operations.readFixedLengthString(ZIP_SIZE, raf).trim();


		Person p= new Person(ID,name,gender, street, city, zip);
		people[i]=p;
		i++;
	}
	public static void ReadFileArray(long position) throws IOException {
		raf.seek(position);
		
		String name = File_Operations.readFixedLengthString(NAME_SIZE, raf);
		String street = File_Operations.readFixedLengthString(STREET_SIZE, raf);
		String city = File_Operations.readFixedLengthString(CITY_SIZE, raf);
		String gender = File_Operations.readFixedLengthString(GENDER_SIZE, raf);
		String zip = File_Operations.readFixedLengthString(ZIP_SIZE, raf);
		
		
		txtID.setText(String.valueOf(ID));
		txtName.setText(name);
		txtStreet.setText(street);
		txtCity.setText(city);
		txtGender.setText(gender);
		txtZip.setText(zip);
	}
	public void PArray(Person[]people,int i)
	{
		txtID.setText(pArray[i].getID());
		txtName.setText(pArray[i].getName());
		txtStreet.setText(pArray[i].getStreet());
		txtCity.setText(pArray[i].getCity());
		txtGender.setText(pArray[i].getGender());
		txtZip.setText(pArray[i].getZip());

	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					Adress_Book window = new Adress_Book();
					window.frame.setVisible(true);
					try {

						if (raf.length() > 0) 
						{
							long currentPos= raf.getFilePointer();
							while(currentPos < raf.length())
							{
								ReadFile(pArray, currentPos);
								currentPos=raf.getFilePointer();
							}
							ReadFileArray(0);
						}
					}
					catch (IOException ex) {
						ex.printStackTrace();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public Adress_Book() {
		try {
			raf = new RandomAccessFile("SaveFiles.dat", "rw");
			pArray=new Person[100];
		}
		catch(IOException ex) {
			ex.printStackTrace();
			System.exit(1);
		}
		initialize();
	}
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.GRAY);
		frame.setBounds(200, 118, 593, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblId = new JLabel("ID");
		lblId.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblId.setHorizontalAlignment(SwingConstants.CENTER);
		lblId.setBounds(0, 43, 46, 14);
		frame.getContentPane().add(lblId);
		txtID = new JTextField();
		txtID.setBounds(44, 40, 86, 20);
		frame.getContentPane().add(txtID);
		txtID.setColumns(10);
		txtID.setEditable(false);
		JLabel lblNewLabel = new JLabel("Search/Uptade ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel.setBounds(140, 40, 118, 14);
		frame.getContentPane().add(lblNewLabel);
		
		txtSearchID = new JTextField();
		txtSearchID.setBounds(254, 40, 171, 20);
		frame.getContentPane().add(txtSearchID);
		txtSearchID.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(0, 78, 46, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Street");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(0, 129, 46, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("City");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(0, 171, 46, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		txtName = new JTextField();
		txtName.setBounds(44, 71, 381, 28);
		frame.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		txtStreet = new JTextField();
		txtStreet.setColumns(10);
		txtStreet.setBounds(44, 122, 381, 28);
		frame.getContentPane().add(txtStreet);
		
		txtCity = new JTextField();
		txtCity.setColumns(10);
		txtCity.setBounds(44, 164, 184, 28);
		frame.getContentPane().add(txtCity);
		
		JLabel lblNewLabel_4 = new JLabel("Gender");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setBounds(238, 171, 46, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblZip = new JLabel("Zip");
		lblZip.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 11));
		lblZip.setHorizontalAlignment(SwingConstants.CENTER);
		lblZip.setBounds(326, 171, 46, 14);
		frame.getContentPane().add(lblZip);
		
		txtGender = new JTextField();
		txtGender.setColumns(10);
		txtGender.setBounds(294, 164, 34, 28);
		frame.getContentPane().add(txtGender);
		
		txtZip = new JTextField();
		txtZip.setColumns(10);
		txtZip.setBounds(374, 164, 55, 28);
		frame.getContentPane().add(txtZip);
		
		JButton AddButton = new JButton("Add");
		AddButton.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 11));
		AddButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					SaveFile(raf.length());
					ReadFile(pArray, RECORD_SIZE*2*(i));
					JOptionPane.showMessageDialog(null, "Record is Succesfully.");
					cleanTextFields();

				} catch (Exception ex) {
				}
			}
		});
		AddButton.setBounds(0, 221, 90, 40);
		frame.getContentPane().add(AddButton);
		JButton first = new JButton("First");
		first.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 11));
		first.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i>0)
				{
					PArray(pArray, 0);
				}
			}
		});
		first.setBounds(106, 221, 90, 40);
		frame.getContentPane().add(first);
		JButton next = new JButton("Next");
		next.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 11));
		next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int id=Integer.parseInt(txtID.getText());
					PArray(pArray, id);
				}
				catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"You reached the end of the list.");
			}
			}
		});
		next.setBounds(218, 221, 90, 40);
		frame.getContentPane().add(next);
		JButton previous = new JButton("Previous");
		previous.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 11));
		previous.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int id=Integer.parseInt(txtID.getText());
					PArray(pArray, id-2);
				}
				catch(Exception ex) {
				JOptionPane.showMessageDialog(null,"You are already in the first element of the list.");
			}
			}
		});
		previous.setBounds(335, 221, 90, 40);
		frame.getContentPane().add(previous);
		
		JButton last = new JButton("Last");
		last.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 11));
		last.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i<=pArray.length)
				{
					PArray(pArray, i-1);
				}

			}
		});
		last.setBounds(458, 221, 118, 40);
		frame.getContentPane().add(last);
		JButton UptadeID = new JButton("UptadeById");
		UptadeID.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 11));
		UptadeID.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				int id=Integer.parseInt(txtSearchID.getText());
				pArray[id-1].setID(txtSearchID.getText());
				pArray[id-1].setName(txtName.getText());
				pArray[id-1].setStreet(txtStreet.getText());
				pArray[id-1].setCity(txtCity.getText());
				pArray[id-1].setGender(txtGender.getText());
				pArray[id-1].setZip(txtZip.getText());
				try {
				Uptade_Person(id-1,txtName.getText(),txtStreet.getText(),txtCity.getText(),txtGender.getText(),txtZip.getText());
				JOptionPane.showMessageDialog(null, "Uptade is Succesful");
				}
				
				catch(Exception ex) {
					
				}
				}
				catch(Exception ex1) {
					JOptionPane.showMessageDialog(null, "Uptade is not Succesful\n\nFirstly Enter and Search the ID ");
					
				}
			}
		});
		UptadeID.setBounds(458, 103, 118, 40);
		frame.getContentPane().add(UptadeID);
		
		JButton btnSearchbyd = new JButton("SearchById");
		btnSearchbyd.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 11));
		btnSearchbyd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				int id=Integer.parseInt(txtSearchID.getText());
				PArray(pArray, id-1);
				
				}catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "No Records Found");
				}
				
			}
		});
		btnSearchbyd.setBounds(458, 43, 118, 40);
		frame.getContentPane().add(btnSearchbyd);
		
	JButton btnCleanTextfields = new JButton("Clean textFields");
	btnCleanTextfields.setForeground(Color.BLACK);
	btnCleanTextfields.setFont(new Font("Bahnschrift", Font.BOLD | Font.ITALIC, 11));
		btnCleanTextfields.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cleanTextFields();
			}
		});
		btnCleanTextfields.setBounds(458, 158, 118, 40);
		frame.getContentPane().add(btnCleanTextfields);
	}
	protected void cleanTextFields() {
		txtID.setText("");
		txtSearchID.setText("");
		txtName.setText("");
		txtStreet.setText("");
		txtCity.setText("");
		txtGender.setText("");
		txtZip.setText("");
		
	}
}
